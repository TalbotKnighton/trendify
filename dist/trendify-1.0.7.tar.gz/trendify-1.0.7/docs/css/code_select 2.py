.language-pycon .gp, .language-pycon .go { /* Generic.Prompt, Generic.Output */
    user-select: none;
}


