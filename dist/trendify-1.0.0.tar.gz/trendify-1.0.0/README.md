
[Read the Docs](https://talbotknighton.github.io/trendify/)