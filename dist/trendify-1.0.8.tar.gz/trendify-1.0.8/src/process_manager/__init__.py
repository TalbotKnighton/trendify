"""
Tools for managing processes and doing them in parallel
"""